# Script: generar_dataset_coquito.py
# Requiere: pip install pandas numpy faker
import pandas as pd
import numpy as np
from faker import Faker
import uuid, random
from datetime import date
fake = Faker('es_CO')
np.random.seed(42)
random.seed(42)
N = 5000

paises = ['Colombia', 'Mexico', 'Argentina', 'Chile', 'Peru',
 'Brasil', 'Ecuador', 'Venezuela', 'Bolivia', 'Uruguay',
 'Paraguay', 'Panama']

categorias_productos = {
 'Snacks': ['Coquito Natural', 'Coquito Tostado', 'Mix Tropical',
 'Bocadillo Premium', 'Galleta Artesanal'],
 'Bebidas': ['Agua de Coco 500ml', 'Jugo Tropical', 'Bebida Energizante',
 'Te Helado Mango', 'Limonada Coco'],
 'Dulces': ['Cocada Original', 'Bombón de Coco', 'Mermelada Tropical',
 'Chocolate Negro 70%', 'Caramelo Artesanal'],
 'Despensa': ['Aceite de Coco 500ml', 'Harina de Coco 1kg',
 'Azúcar de Coco 500g', 'Leche de Coco 400ml', 'Coco Rallado 250g'],
 'Cuidado Personal': ['Crema Corporal Coco', 'Shampoo Coco 300ml',
 'Jabón Artesanal', 'Aceite Capilar', 'Protector Solar SPF50'],
 'Hogar': ['Vela Aromática Coco', 'Ambientador Natural', 'Jabón Loza Coco',
 'Suavizante Ropa', 'Desinfectante Citrus']
}

metodos_pago = ['Tarjeta Crédito', 'Tarjeta Débito', 'PSE', 'Nequi', 'PayPal',
'Efecty']

fechas = pd.date_range('2024-01-01', '2024-12-31', periods=N)
registros = []

for i in range(N):
 cat = random.choice(list(categorias_productos.keys()))
 prod = random.choice(categorias_productos[cat])
 pais = random.choices(paises, weights=[30,20,10,8,8,5,5,3,3,2,2,4])[0]
 qty = random.randint(1, 10)
 precio = round(random.uniform(0.5, 50.0), 2)
 devuelto = random.random() < 0.08 # 8% tasa devolución
 calif = random.choices([1,2,3,4,5], weights=[3,5,15,40,37])[0]
 registros.append({
 'order_id': str(uuid.uuid4()),
 'fecha_pedido': fechas[i].date(),
 'cliente_id': f'C{random.randint(1,2000):04d}',
 'pais_destino': pais,
 'categoria': cat,
 'producto': prod,
 'cantidad': qty,
 'precio_unitario': precio,
 'total_pedido': round(qty * precio, 2),
 'metodo_pago': random.choice(metodos_pago),
 'fue_devuelto': devuelto,
 'calificacion': calif
 })

df = pd.DataFrame(registros)
df.to_csv('coquito_amarillo_ecommerce.csv', index=False, encoding='utf-8')
print(f'Dataset generado: {len(df)} filas')
print(df.head())
print(df.dtypes)